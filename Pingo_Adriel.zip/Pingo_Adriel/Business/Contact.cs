﻿using AutoMapper;
using Business.Interface;
using Business.Model;
using DataAccess.Repository;

namespace Business
{
    public class Contact : IContact
    {
        private readonly IMapper _mapper;

        private ContactRepository _contactRepository;

        public Contact(ContactRepository contactRepository) { _contactRepository = contactRepository; }

        public IList<ContactModel> GetContactsByClientId(int clientId)
        {
            return _mapper.Map<IList<ContactModel>>(_contactRepository.GetContactsByClientId(clientId));
        }

        public int CreateContact(ContactModel contactModel)
        {
            var contact = _mapper.Map<DataAccess.Entities.Contact>(contactModel);

            return _contactRepository.CreateContact(contact);
        }

        public int UpdateContact(ContactModel contactModel)
        {
            var contact = _mapper.Map<DataAccess.Entities.Contact>(contactModel);

            return _contactRepository.UpdateContact(contact);
        }

        public bool DeleteContact(int id)
        {
            return _contactRepository.DeleteContact(id);
        }
    }
}
