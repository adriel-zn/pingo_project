﻿using AutoMapper;
using Business.Interface;
using Business.Model;
using DataAccess.Repository;

namespace Business
{
    public class Client : IClient
    {
        private readonly IMapper _mapper;

        private ClientRepository _clientRepository;

        public Client(ClientRepository clientRepository) {  _clientRepository = clientRepository; }

        public ClientModel GetClientsById(int clientId)
        {
            return _mapper.Map<ClientModel>(_clientRepository.GetClientsById(clientId));
        }

        public IList<ClientModel> GetAllClientsWithDetails()
        {
            return _mapper.Map<IList<ClientModel>>(_clientRepository.GetAllClientsWithDetails());
        }

        public int CreateClient(ClientModel clientModel)
        {
            var client = _mapper.Map<DataAccess.Entities.Client>(clientModel);

            return _clientRepository.CreateClient(client);
        }

        public int UpdateClient(ClientModel clientModel)
        {
            var client = _mapper.Map<DataAccess.Entities.Client>(clientModel);

            return _clientRepository.UpdateClient(client);
        }

        public bool DeleteClient(int id)
        {
            return _clientRepository.DeleteClient(id);
        }
    }
}
