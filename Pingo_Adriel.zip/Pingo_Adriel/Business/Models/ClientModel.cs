﻿using System.ComponentModel;

namespace Business.Models
{
    public class ClientModel
    {
        public int Id { get; set; }
        public string? IdentityNumber { get; set; }
        public string? Passport { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public Gender Gender { get; set; } = Gender.None;


        #region Custom
        public IList<AddressModel> Addresses { get; set; } = new List<AddressModel>();
        public IList<ContactModel> Contacts { get; set; } = new List<ContactModel>();
        #endregion
    }

    public enum Gender
    {
        [Description("None")]
        None,
        [Description("Male")]
        Male,
        [Description("Female")]
        Female
    }
}
