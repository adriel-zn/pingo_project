﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Models
{
    public class ContactModel
    {
        public int Id { get; set; }
        public int ClientId { get; set; }
        public string? Value { get; set; }
        public ContactType Type { get; set; }
    }

    public enum ContactType
    {
        [Description("None")]
        None,
        [Description("Email")]
        Email,
        [Description("Mobile")]
        Mobile,
        [Description("Telephone")]
        Telephone
    }
}
