﻿using Business.Model;
using DataAccess.Entities;
using DataAccess.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Interface
{
    public interface IClient
    {
        ClientModel GetClientsById(int clientId);
        IList<ClientModel> GetAllClientsWithDetails();
        int CreateClient(ClientModel clientModel);
        int UpdateClient(ClientModel clientModel);
        bool DeleteClient(int id);

    }
}
