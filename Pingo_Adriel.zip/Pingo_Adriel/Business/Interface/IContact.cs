﻿using Business.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Interface
{
    public interface IContact
    {
        IList<ContactModel> GetContactsByClientId(int clientId);
        int CreateContact(ContactModel contactModel);
        int UpdateContact(ContactModel contactModel);
        bool DeleteContact(int id);
    }
}
