﻿using AutoMapper;
using Business.Interface;
using Business.Model;
using DataAccess.Repository;

namespace Business
{
    public class Address : IAddress
    {
        private readonly IMapper _mapper;

        private AddressRepository _addressRepository;

        public Address(AddressRepository addressRepository) { _addressRepository = addressRepository; }

        public IList<AddressModel> GetAddressesByClientId(int clientId)
        {
            return _mapper.Map<IList<AddressModel>>(_addressRepository.GetAddressesByClientId(clientId));
        }

        public int CreateAddress(AddressModel addressModel)
        {
            var address = _mapper.Map<DataAccess.Entities.Address>(addressModel);

            return _addressRepository.CreateAddress(address);
        }

        public int UpdateAddress(AddressModel addressModel)
        {
            var address = _mapper.Map<DataAccess.Entities.Address>(addressModel);

            return _addressRepository.UpdateAddress(address);
        }

        public bool DeleteAddress(int id)
        {
            return _addressRepository.DeleteAddress(id);
        }
    }
}
