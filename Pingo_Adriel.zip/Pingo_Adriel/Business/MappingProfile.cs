﻿using AutoMapper;
using Business.Model;

namespace Business
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Client, ClientModel>().ReverseMap();
        }   
    }
}
