﻿using Microsoft.AspNetCore.Mvc;

namespace Client.Services.Controllers
{
    public class ClientController : Controller
    {
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            return View();
        }
    }
}
