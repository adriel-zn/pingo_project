﻿using Business.Interface;
using Microsoft.AspNetCore.Mvc;

namespace Client.Services.Controllers
{
    public class AddressController : Controller
    {
        private readonly IClient _client;

        public IActionResult Index()
        {
            var client = _client.GetAllClientsWithDetails();
            return View(client);
        }
    }
}
