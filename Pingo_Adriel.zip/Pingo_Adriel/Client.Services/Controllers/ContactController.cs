﻿using Microsoft.AspNetCore.Mvc;

namespace Client.Services.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
