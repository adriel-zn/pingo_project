﻿namespace DataAccess.Entities
{
    public class Client
    {
        public int Id { get; set; }
        public string? IdentityNumber { get; set; }
        public string? Passport { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public int? Gender { get; set; }


        #region Custom
        public IList<Address> Addresses { get; set; } = new List<Address>();
        public IList<Contact> Contacts { get; set; } = new List<Contact>();
        #endregion
    }
}
