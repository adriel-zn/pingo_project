﻿namespace DataAccess.Entities
{
    public class Contact
    {
        public int Id { get; set; }
        public int ClientId { get; set; }
        public string? Value { get; set; }
        public int? Type { get; set; }
    }
}
