﻿using DataAccess.Entities;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess.Repository
{
    public class ClientRepository
    {
        private string _connection = "";

        public Client GetClientsById(int clientId)
        {
            var client = new Client();

            using (SqlConnection connection = new SqlConnection(_connection))
            {
                connection.Open();

                string sql = @"select * 
                               from dbo.Client";

                SqlCommand command = new SqlCommand(sql, connection);

                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        client = new Client
                        {
                            Id = Convert.ToInt32(dataReader["Id"]),
                            FirstName = Convert.ToString(dataReader["FirstName"]),
                            LastName = Convert.ToString(dataReader["LastName"]),
                            IdentityNumber = Convert.ToString(dataReader["IdentityNumber"]),
                            Passport = Convert.ToString(dataReader["Passport"]),
                            Gender = Convert.ToInt32(dataReader["Gender"])
                        };

                    }
                }

                connection.Close();
            }

            return client;
        }

        public IList<Client> GetAllClientsWithDetails()
        {
            var clientList = new List<Client>();

            using (SqlConnection connection = new SqlConnection(_connection))
            {
                connection.Open();

                string sql = @"select c.*, a.*, ct.* 
                               from dbo.Client c
	                                left join dbo.[Address] a 
		                                on a.ClientId = c.Id
	                                left join dbo.Contact ct 
		                                on ct.ClientId = c.Id";

                SqlCommand command = new SqlCommand(sql, connection);

                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Client client = new Client
                        {
                            Id = Convert.ToInt32(dataReader["Id"]),
                            FirstName = Convert.ToString(dataReader["FirstName"]),
                            LastName = Convert.ToString(dataReader["LastName"]),
                            IdentityNumber = Convert.ToString(dataReader["IdentityNumber"]),
                            Passport = Convert.ToString(dataReader["Passport"]),
                            Gender = Convert.ToInt32(dataReader["Gender"])
                        };

                        clientList.Add(client);
                    }
                }


                connection.Close();
            }

            return clientList;
        }

        public int CreateClient(Client client)
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                string sql = @"
insert into dbo.Client ([IdentityNumber], [PassportNumber], [FirstName], [LastName], [DateOfBirth], [Gender])
values(@IdentityNumber,@PassportNumber,@FirstName,@LastName,@DateOfBirth,@Gender)
select SCOPE_IDENTITY() as Id";

                SqlCommand command = new(sql, connection)
                {
                    CommandType = CommandType.Text
                };

                command.Parameters.AddWithValue("@IdentityNumber", client.IdentityNumber);
                command.Parameters.AddWithValue("@PassportNumber", client.Passport);
                command.Parameters.AddWithValue("@FirstName", client.FirstName);
                command.Parameters.AddWithValue("@LastName", client.LastName);
                command.Parameters.AddWithValue("@DateOfBirth", client.DateOfBirth);
                command.Parameters.AddWithValue("@Gender", client.Gender);

                connection.Open();

                int id = command.ExecuteNonQuery();

                connection.Close();

                return id;
            }


        }

        public int UpdateClient(Client client)
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                string sql = @"
update dbo.Client 
set  
	[IdentityNumber]=@IdentityNumber, 
	[PassportNumber]=@PassportNumber, 
	[FirstName]=@FirstName, 
	[LastName]=@LastName, 
	[DateOfBirth]=@DateOfBirth, 
	[Gender]=@Gender
where Id = @Id";

                SqlCommand command = new(sql, connection)
                {
                    CommandType = CommandType.Text
                };

                command.Parameters.AddWithValue("@IdentityNumber", client.IdentityNumber);
                command.Parameters.AddWithValue("@PassportNumber", client.Passport);
                command.Parameters.AddWithValue("@FirstName", client.FirstName);
                command.Parameters.AddWithValue("@LastName", client.LastName);
                command.Parameters.AddWithValue("@DateOfBirth", client.DateOfBirth);
                command.Parameters.AddWithValue("@Gender", client.Gender);

                connection.Open();

                int id = command.ExecuteNonQuery();

                connection.Close();

                return id;
            }


        }

        public bool DeleteClient(int id) 
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                string sql = @"
delete dbo.Client
where Id = @Id";

                SqlCommand command = new(sql, connection)
                {
                    CommandType = CommandType.Text
                };

                command.Parameters.AddWithValue("@Id", id);

                connection.Open();

                int i = command.ExecuteNonQuery();

                connection.Close();

                if (i >= 1)
                    return true;
                else
                    return false;
            }
        }

    }
}
