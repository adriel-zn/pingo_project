﻿using DataAccess.Entities;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Metrics;

namespace DataAccess.Repository
{
    public class AddressRepository
    {
        private string _connection = "";

        public IList<Address> GetAddressesByClientId(int clientId)
        {
            var addresses = new List<Address>();

            using (SqlConnection connection = new SqlConnection(_connection))
            {
                connection.Open();

                string sql = @"select * 
                               from dbo.[Address] where ClientId = @ClientId";

                SqlCommand command = new(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                command.Parameters.AddWithValue("@ClientId", clientId);

                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Address address = new Address
                        {
                            Id = Convert.ToInt32(dataReader["Id"]),
                            Address1 = Convert.ToString(dataReader["Address1"]),
                            Address2 = Convert.ToString(dataReader["Address2"]),
                            Address3 = Convert.ToString(dataReader["Address3"]),
                            ClientId = Convert.ToInt32(dataReader["ClientId"]),
                            City = Convert.ToString(dataReader["City"]),
                            State = Convert.ToString(dataReader["State"]),
                            Country = Convert.ToString(dataReader["Country"]),
                            IsDefault = Convert.ToBoolean(dataReader["IsDefault"]),
                            PostalCode = Convert.ToString(dataReader["PostalCode"]),
                        };

                        addresses.Add(address);

                    }
                }

                connection.Close();
            }

            return addresses;
        }

        public int CreateAddress(Address address)
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                string sql = @"
insert into dbo.Address ([ClientId], [Address1], [Address2], [Address3], [City], [State], [Country], [PostalCode], [IsDefault])
values(@ClientId,@Address1,@Address2,@Address3,@City,@State,@Country,@PostalCode,@IsDefault)
select SCOPE_IDENTITY() as Id";

                SqlCommand command = new(sql, connection)
                {
                    CommandType = CommandType.Text
                };

                command.Parameters.AddWithValue("@ClientId", address.ClientId);
                command.Parameters.AddWithValue("@Address1", address.Address1);
                command.Parameters.AddWithValue("@Address2", address.Address2);
                command.Parameters.AddWithValue("@Address3", address.Address3);
                command.Parameters.AddWithValue("@City", address.City);
                command.Parameters.AddWithValue("@State", address.State);
                command.Parameters.AddWithValue("@Country", address.Country);
                command.Parameters.AddWithValue("@PostalCode", address.PostalCode);
                command.Parameters.AddWithValue("@IsDefault", address.IsDefault);

                connection.Open();

                int id = command.ExecuteNonQuery();

                connection.Close();

                return id;
            }


        }

        public int UpdateAddress(Address address)
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                string sql = @"
update dbo.[Address]
set  
	[ClientId] = @ClientId, 
    [Address1] = @Address1, 
    [Address2] = @Address2, 
    [Address3] =@Address3, 
    [City]=@City, 
    [State]=@State, 
    [Country]=@Country, 
    [PostalCode]=@PostalCode, 
    [IsDefault]=@IsDefault
where Id = @Id";

                SqlCommand command = new(sql, connection)
                {
                    CommandType = CommandType.Text
                };

                command.Parameters.AddWithValue("@ClientId", address.ClientId);
                command.Parameters.AddWithValue("@Address1", address.Address1);
                command.Parameters.AddWithValue("@Address2", address.Address2);
                command.Parameters.AddWithValue("@Address3", address.Address3);
                command.Parameters.AddWithValue("@City", address.City);
                command.Parameters.AddWithValue("@State", address.State);
                command.Parameters.AddWithValue("@Country", address.Country);
                command.Parameters.AddWithValue("@PostalCode", address.PostalCode);
                command.Parameters.AddWithValue("@IsDefault", address.IsDefault);


                connection.Open();

                int id = command.ExecuteNonQuery();

                connection.Close();

                return id;
            }


        }

        public bool DeleteAddress(int id) 
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                string sql = @"
delete dbo.[Address]
where Id = @Id";

                SqlCommand command = new(sql, connection)
                {
                    CommandType = CommandType.Text
                };

                command.Parameters.AddWithValue("@Id", id);

                connection.Open();

                int i = command.ExecuteNonQuery();

                connection.Close();

                if (i >= 1)
                    return true;
                else
                    return false;
            }
        }

    }
}
