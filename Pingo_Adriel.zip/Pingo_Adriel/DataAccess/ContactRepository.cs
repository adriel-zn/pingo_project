﻿using DataAccess.Entities;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess.Repository
{
    public class ContactRepository
    {
        private string _connection = "";

        public IList<Contact> GetContactsByClientId(int clientId)
        {
            var contacts = new List<Contact>();

            using (SqlConnection connection = new SqlConnection(_connection))
            {
                connection.Open();

                string sql = @"select * 
                               from dbo.[Contact] where ClientId = @ClientId";

                SqlCommand command = new(sql, connection)
                {
                    CommandType = CommandType.Text
                };
                command.Parameters.AddWithValue("@ClientId", clientId);

                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Contact contact = new Contact
                        {
                            Id = Convert.ToInt32(dataReader["Id"]),
                            Value = Convert.ToString(dataReader["Value"]),
                            ClientId = Convert.ToInt32(dataReader["ClientId"]),
                            Type = Convert.ToInt32(dataReader["Type"])
                        };


                        contacts.Add(contact);
                    }
                }

                connection.Close();
            }

            return contacts;
        }

        public int CreateContact(Contact contact)
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                string sql = @"
insert into dbo.Contact ([ClientId], [Value], [Type])
values(@ClientId,@Value,@Type)
select SCOPE_IDENTITY() as Id";

                SqlCommand command = new(sql, connection)
                {
                    CommandType = CommandType.Text
                };

                command.Parameters.AddWithValue("@ClientId", contact.ClientId);
                command.Parameters.AddWithValue("@Value", contact.Value);
                command.Parameters.AddWithValue("@Type", contact.Type);

                connection.Open();

                int id = command.ExecuteNonQuery();

                connection.Close();

                return id;
            }


        }

        public int UpdateContact(Contact contact)
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                string sql = @"
update dbo.Contact 
set  
	[ClientId]=@ClientId, [Value]=@Value, [Type]=@Type
where Id = @Id";

                SqlCommand command = new(sql, connection)
                {
                    CommandType = CommandType.Text
                };

                command.Parameters.AddWithValue("@ClientId", contact.ClientId);
                command.Parameters.AddWithValue("@Value", contact.Value);
                command.Parameters.AddWithValue("@Type", contact.Type);

                connection.Open();

                int id = command.ExecuteNonQuery();

                connection.Close();

                return id;
            }


        }

        public bool DeleteContact(int id) 
        {
            using (SqlConnection connection = new SqlConnection(_connection))
            {
                string sql = @"
delete dbo.Contact
where Id = @Id";

                SqlCommand command = new(sql, connection)
                {
                    CommandType = CommandType.Text
                };

                command.Parameters.AddWithValue("@Id", id);

                connection.Open();

                int i = command.ExecuteNonQuery();

                connection.Close();

                if (i >= 1)
                    return true;
                else
                    return false;
            }
        }

    }
}
